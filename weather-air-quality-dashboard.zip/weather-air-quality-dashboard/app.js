"use strict";

// Atmos: Weather & Air Quality Dashboard
// Data services: Open-Meteo Weather, Air Quality and Geocoding APIs.

const API = Object.freeze({
  weather: "https://api.open-meteo.com/v1/forecast",
  air: "https://air-quality-api.open-meteo.com/v1/air-quality",
  geocoding: "https://geocoding-api.open-meteo.com/v1/search"
});
const MAX_CITIES = 6;
const STORAGE = Object.freeze({
  cities: "atmos-dashboard-cities-v1",
  favourites: "atmos-dashboard-favourites-v1"
});
const CITY_COLORS = ["#278b78", "#7798ed", "#df9b52", "#a68add", "#e57e80", "#52aebe"];
const REQUEST_TIMEOUT_MS = 15000;

const DEFAULT_CITIES = [
  { name: "Panipat", admin1: "Haryana", country: "India", latitude: 29.3909, longitude: 76.9635 },
  { name: "New Delhi", admin1: "Delhi", country: "India", latitude: 28.6139, longitude: 77.2090 },
  { name: "Mumbai", admin1: "Maharashtra", country: "India", latitude: 19.0760, longitude: 72.8777 }
];

const el = {
  cityGrid: document.querySelector("#cityGrid"),
  favoritesList: document.querySelector("#favoritesList"),
  cityCount: document.querySelector("#cityCount"),
  savedCount: document.querySelector("#savedCount"),
  status: document.querySelector("#statusMessage"),
  searchResults: document.querySelector("#searchResults"),
  cityForm: document.querySelector("#cityForm"),
  cityInput: document.querySelector("#cityInput"),
  addCityButton: document.querySelector("#addCityButton"),
  refreshButton: document.querySelector("#refreshButton"),
  temperatureCanvas: document.querySelector("#temperatureChart"),
  aqiCanvas: document.querySelector("#aqiChart")
};

function normalizeCity(input) {
  if (!input || typeof input !== "object") return null;
  const latitude = Number(input.latitude);
  const longitude = Number(input.longitude);
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90 ||
      !Number.isFinite(longitude) || longitude < -180 || longitude > 180) return null;
  const city = {
    name: String(input.name || "Unknown city").trim().slice(0, 100),
    admin1: String(input.admin1 || "").trim().slice(0, 100),
    country: String(input.country || "").trim().slice(0, 100),
    latitude,
    longitude
  };
  if (!city.name) return null;
  // Four decimal places are precise enough to distinguish typical city search results.
  city.id = `${latitude.toFixed(4)}:${longitude.toFixed(4)}`;
  return city;
}

function safeReadCityList(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) return fallback.map(normalizeCity).filter(Boolean);
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return fallback.map(normalizeCity).filter(Boolean);
    const unique = new Map();
    for (const entry of parsed) {
      const city = normalizeCity(entry);
      if (city && !unique.has(city.id)) unique.set(city.id, city);
    }
    return [...unique.values()];
  } catch (error) {
    console.warn(`Unable to read ${key} from localStorage.`, error);
    return fallback.map(normalizeCity).filter(Boolean);
  }
}

const state = {
  cities: safeReadCityList(STORAGE.cities, DEFAULT_CITIES).slice(0, MAX_CITIES),
  favourites: safeReadCityList(STORAGE.favourites, []),
  cityData: new Map(),
  searchMatches: [],
  temperatureChart: null,
  aqiChart: null,
  refreshGeneration: 0
};

function persist(key, value, errorMessage) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.warn(`Unable to save ${key} to localStorage.`, error);
    showStatus(errorMessage, "error");
  }
}

function saveCities() { persist(STORAGE.cities, state.cities, "Your browser could not save the comparison list."); }
function saveFavourites() { persist(STORAGE.favourites, state.favourites, "Your browser could not save favourite cities."); }

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function showStatus(message, type = "info") {
  el.status.textContent = message;
  el.status.className = `status-message visible ${type}`;
}
function clearStatus() {
  el.status.textContent = "";
  el.status.className = "status-message";
}
function hideSearchResults() {
  state.searchMatches = [];
  el.searchResults.replaceChildren();
  el.searchResults.hidden = true;
}
function formatNumber(value, digits = 0) {
  if (value === null || value === undefined || value === "" || !Number.isFinite(Number(value))) return "—";
  return Number(value).toFixed(digits);
}
function locationDetail(city) {
  return [city.admin1, city.country].filter(Boolean).join(", ") || "Location details unavailable";
}

function describeWeather(code) {
  const value = Number(code);
  if (value === 0) return { icon: "☀️", text: "Clear sky" };
  if ([1, 2].includes(value)) return { icon: "🌤️", text: "Partly cloudy" };
  if (value === 3) return { icon: "☁️", text: "Overcast" };
  if ([45, 48].includes(value)) return { icon: "🌫️", text: "Fog" };
  if ([51, 53, 55, 56, 57].includes(value)) return { icon: "🌦️", text: "Drizzle" };
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(value)) return { icon: "🌧️", text: "Rain / showers" };
  if ([71, 73, 75, 77, 85, 86].includes(value)) return { icon: "🌨️", text: "Snow" };
  if ([95, 96, 99].includes(value)) return { icon: "⛈️", text: "Thunderstorm" };
  return { icon: "🌡️", text: "Conditions unavailable" };
}

function getEuropeanAqiInfo(value) {
  if (value === null || value === undefined || !Number.isFinite(Number(value))) {
    return { label: "Unavailable", className: "aqi-unknown" };
  }
  const aqi = Number(value);
  if (aqi < 20) return { label: "Good", className: "aqi-good" };
  if (aqi < 40) return { label: "Fair", className: "aqi-fair" };
  if (aqi < 60) return { label: "Moderate", className: "aqi-moderate" };
  if (aqi < 80) return { label: "Poor", className: "aqi-poor" };
  if (aqi <= 100) return { label: "Very poor", className: "aqi-vpoor" };
  return { label: "Extremely poor", className: "aqi-extreme" };
}

async function fetchJSON(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(url, { signal: controller.signal, headers: { Accept: "application/json" } });
    let payload;
    try { payload = await response.json(); }
    catch { throw new Error("The data service returned an unreadable response."); }
    if (!response.ok || payload?.error) {
      throw new Error(payload?.reason || `Request failed (${response.status}).`);
    }
    return payload;
  } catch (error) {
    if (error.name === "AbortError") throw new Error("The request timed out. Please try again.");
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

function assertHasHourlyWeather(payload) {
  if (!payload?.current || !Array.isArray(payload?.hourly?.time) || !Array.isArray(payload?.hourly?.temperature_2m)) {
    throw new Error("The weather service returned incomplete data.");
  }
}

async function fetchCityData(city) {
  const common = { latitude: String(city.latitude), longitude: String(city.longitude), timezone: "GMT" };
  const weatherParams = new URLSearchParams({
    ...common,
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
    hourly: "temperature_2m",
    forecast_hours: "24"
  });
  const airParams = new URLSearchParams({
    ...common,
    current: "european_aqi,pm2_5,pm10",
    hourly: "european_aqi,pm2_5,pm10",
    forecast_hours: "24"
  });

  const [weatherResult, airResult] = await Promise.allSettled([
    fetchJSON(`${API.weather}?${weatherParams}`),
    fetchJSON(`${API.air}?${airParams}`)
  ]);
  if (weatherResult.status === "rejected") throw weatherResult.reason;
  assertHasHourlyWeather(weatherResult.value);
  const air = airResult.status === "fulfilled" ? airResult.value : null;
  return {
    weather: weatherResult.value,
    air,
    airError: airResult.status === "rejected" ? "Air-quality information is temporarily unavailable." : ""
  };
}

function renderSearchResults(matches) {
  state.searchMatches = matches.map(normalizeCity).filter(Boolean);
  el.searchResults.replaceChildren();
  if (!state.searchMatches.length) {
    el.searchResults.hidden = true;
    showStatus("No matching city found. Try another spelling or include the country name.", "error");
    return;
  }
  el.searchResults.innerHTML = `
    <p class="search-results-heading">Choose the correct location</p>
    <div class="search-results-options">${state.searchMatches.map((city, index) => `
      <button class="search-result-option" type="button" data-search-result="${index}">
        <span class="search-result-name">${escapeHTML(city.name)}</span>
        <span class="search-result-detail">${escapeHTML(locationDetail(city))}</span>
        <span class="search-result-coords">${city.latitude.toFixed(2)}, ${city.longitude.toFixed(2)}</span>
      </button>`).join("")}</div>`;
  el.searchResults.hidden = false;
  showStatus(`Found ${state.searchMatches.length} matching location${state.searchMatches.length === 1 ? "" : "s"}. Select the city you want to compare.`, "info");
}

function renderFavouriteCities() {
  el.savedCount.textContent = String(state.favourites.length);
  if (!state.favourites.length) {
    el.favoritesList.innerHTML = '<p class="favorite-empty">No favourites yet. Select the ☆ on a city card to save it here.</p>';
    return;
  }
  el.favoritesList.innerHTML = state.favourites.map(city => {
    const isCompared = state.cities.some(item => item.id === city.id);
    const label = isCompared ? "Already comparing" : "Add to comparison";
    return `<div class="favorite-item">
      <button class="favorite-compare" type="button" data-recompare="${escapeHTML(city.id)}" title="${label}" ${isCompared ? "disabled" : ""}>
        <span aria-hidden="true">★</span>${escapeHTML(city.name)}${isCompared ? " · In comparison" : ""}
      </button>
      <button class="favorite-remove" type="button" data-unfavorite="${escapeHTML(city.id)}" aria-label="Remove ${escapeHTML(city.name)} from saved cities" title="Remove favourite">×</button>
    </div>`;
  }).join("");
}

function renderCityCards() {
  el.cityCount.textContent = String(state.cities.length);
  if (!state.cities.length) {
    el.cityGrid.innerHTML = '<div class="empty-state"><strong>Your comparison is empty.</strong>Search for a city above or add one from your saved cities.</div>';
    return;
  }
  el.cityGrid.innerHTML = state.cities.map((city, index) => {
    const favourite = state.favourites.some(item => item.id === city.id);
    const data = state.cityData.get(city.id);
    const cityName = escapeHTML(city.name);
    const details = escapeHTML(locationDetail(city));
    const coords = `${city.latitude.toFixed(2)}, ${city.longitude.toFixed(2)}`;
    const actions = `<div class="card-actions">
      <button class="icon-button ${favourite ? "is-favourite" : ""}" type="button" data-favourite="${escapeHTML(city.id)}" aria-label="${favourite ? "Remove" : "Save"} ${cityName} ${favourite ? "from" : "to"} favourites" title="${favourite ? "Remove favourite" : "Save favourite"}">${favourite ? "★" : "☆"}</button>
      <button class="icon-button" type="button" data-remove-city="${escapeHTML(city.id)}" aria-label="Remove ${cityName} from comparison" title="Remove from comparison">×</button>
    </div>`;
    let cardContent = '<div class="loading-state">Loading weather and air-quality data…</div>';
    if (data?.error) {
      cardContent = `<div class="card-error">Couldn't load this city's weather data.<br><small>${escapeHTML(data.error)}</small><p>Check your connection and select “Refresh data”.</p></div>`;
    } else if (data) {
      const weather = data.weather.current || {};
      const air = data.air?.current || {};
      const condition = describeWeather(weather.weather_code);
      const aqiInfo = getEuropeanAqiInfo(air.european_aqi);
      const airNote = data.airError ? `<p class="feels-like air-data-note">${escapeHTML(data.airError)}</p>` : "";
      cardContent = `
        <div class="temperature-row"><span class="temperature-value">${formatNumber(weather.temperature_2m)}°</span><span class="weather-condition">${condition.text}</span></div>
        <p class="feels-like">Feels like ${formatNumber(weather.apparent_temperature)}°C</p>
        ${airNote}
        <div class="metric-grid">
          <div class="metric"><div class="metric-label">Humidity</div><div class="metric-value">${formatNumber(weather.relative_humidity_2m)}<span class="metric-unit"> %</span></div></div>
          <div class="metric"><div class="metric-label">Wind speed</div><div class="metric-value">${formatNumber(weather.wind_speed_10m, 1)}<span class="metric-unit"> km/h</span></div></div>
          <div class="metric"><div class="metric-label">European AQI</div><div class="metric-value">${formatNumber(air.european_aqi)}<span class="metric-unit"> index</span></div><span class="aqi-pill ${aqiInfo.className}">${aqiInfo.label}</span></div>
          <div class="metric"><div class="metric-label">PM2.5</div><div class="metric-value">${formatNumber(air.pm2_5, 1)}<span class="metric-unit"> µg/m³</span></div></div>
          <div class="metric"><div class="metric-label">PM10</div><div class="metric-value">${formatNumber(air.pm10, 1)}<span class="metric-unit"> µg/m³</span></div></div>
        </div>
        <div class="card-footer"><span class="coordinates">${coords}</span><span>${weather.time ? `Updated ${escapeHTML(weather.time.slice(11, 16))} UTC` : "Current conditions"}</span></div>`;
    }
    const icon = data?.weather?.current ? describeWeather(data.weather.current.weather_code).icon : "🌍";
    return `<article class="city-card" style="--city-accent:${CITY_COLORS[index % CITY_COLORS.length]}">
      <div class="city-card-top"><div class="city-heading"><div class="city-weather-icon" aria-hidden="true">${icon}</div><div class="city-title-wrap"><h3>${cityName}</h3><p>${details}</p></div></div>${actions}</div>
      ${cardContent}
    </article>`;
  }).join("");
}

function formatHour(isoTime) {
  // All forecast requests ask for GMT, making the chart's timeline common across cities.
  return `${String(isoTime).slice(11, 16)} UTC`;
}

function chartOptions(yTitle, beginAtZero = false) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: "index", intersect: false },
    plugins: {
      legend: { position: "bottom", labels: { usePointStyle: true, pointStyle: "circle", boxWidth: 7, boxHeight: 7, padding: 15, color: "#627873", font: { family: "DM Sans", size: 10 } } },
      tooltip: { backgroundColor: "#153e38", padding: 11, titleFont: { family: "DM Sans", size: 11 }, bodyFont: { family: "DM Sans", size: 11 }, cornerRadius: 8 }
    },
    scales: {
      x: { grid: { display: false }, border: { display: false }, ticks: { color: "#91a09a", maxTicksLimit: 7, maxRotation: 0, font: { family: "DM Sans", size: 9 } } },
      y: { beginAtZero, title: { display: true, text: yTitle, color: "#91a09a", font: { family: "DM Sans", size: 9 } }, grid: { color: "#edf2ef" }, border: { display: false }, ticks: { color: "#91a09a", font: { family: "DM Sans", size: 9 }, maxTicksLimit: 5 } }
    }
  };
}

function makeTimeMap(times, values) {
  const result = new Map();
  if (!Array.isArray(times) || !Array.isArray(values)) return result;
  times.forEach((time, index) => result.set(time, values[index] ?? null));
  return result;
}

function destroyCharts() {
  state.temperatureChart?.destroy();
  state.aqiChart?.destroy();
  state.temperatureChart = null;
  state.aqiChart = null;
}

function updateCharts() {
  destroyCharts();
  const available = state.cities
    .map(city => ({ city, data: state.cityData.get(city.id) }))
    .filter(item => item.data && !item.data.error);
  if (!available.length) return;
  if (typeof Chart === "undefined") {
    showStatus("Chart.js did not load. Check your internet connection and reload the page.", "error");
    return;
  }

  // Build a union of UTC timestamps and align each city's values by timestamp rather than array index.
  const weatherSeries = available.map(({ city, data }) => ({
    city,
    timeMap: makeTimeMap(data.weather.hourly?.time, data.weather.hourly?.temperature_2m)
  }));
  const temperatureTimes = [...new Set(weatherSeries.flatMap(series => [...series.timeMap.keys()]))].sort();
  if (temperatureTimes.length) {
    state.temperatureChart = new Chart(el.temperatureCanvas, {
      type: "line",
      data: {
        labels: temperatureTimes.map(formatHour),
        datasets: weatherSeries.map(series => ({
          label: series.city.name,
          data: temperatureTimes.map(time => series.timeMap.has(time) ? series.timeMap.get(time) : null),
          borderColor: CITY_COLORS[state.cities.findIndex(city => city.id === series.city.id) % CITY_COLORS.length],
          backgroundColor: "transparent", borderWidth: 2, pointRadius: 0, pointHoverRadius: 4, tension: 0.35, spanGaps: false
        }))
      },
      options: chartOptions("Temperature (°C)")
    });
  }

  const airSeries = available.filter(({ data }) => Array.isArray(data.air?.hourly?.european_aqi));
  const aqiMaps = airSeries.map(({ city, data }) => ({
    city,
    timeMap: makeTimeMap(data.air.hourly.time, data.air.hourly.european_aqi)
  }));
  const aqiTimes = [...new Set(aqiMaps.flatMap(series => [...series.timeMap.keys()]))].sort();
  const hasAqiValues = aqiMaps.some(series => [...series.timeMap.values()].some(value => value !== null && value !== undefined));
  if (aqiTimes.length && hasAqiValues) {
    state.aqiChart = new Chart(el.aqiCanvas, {
      type: "line",
      data: {
        labels: aqiTimes.map(formatHour),
        datasets: aqiMaps.map(series => ({
          label: series.city.name,
          data: aqiTimes.map(time => series.timeMap.has(time) ? series.timeMap.get(time) : null),
          borderColor: CITY_COLORS[state.cities.findIndex(city => city.id === series.city.id) % CITY_COLORS.length],
          backgroundColor: "transparent", borderWidth: 2, pointRadius: 0, pointHoverRadius: 4, tension: 0.35, spanGaps: false
        }))
      },
      options: chartOptions("European AQI", true)
    });
  }
}

async function refreshDashboard() {
  const generation = ++state.refreshGeneration;
  renderCityCards();
  renderFavouriteCities();
  if (!state.cities.length) {
    state.cityData.clear();
    updateCharts();
    el.refreshButton.disabled = false;
    el.refreshButton.innerHTML = '<span aria-hidden="true">↻</span> Refresh data';
    return;
  }
  el.refreshButton.disabled = true;
  el.refreshButton.innerHTML = '<span aria-hidden="true">↻</span> Loading…';
  const citiesAtStart = [...state.cities];
  const results = await Promise.all(citiesAtStart.map(async city => {
    try { return { id: city.id, value: await fetchCityData(city) }; }
    catch (error) {
      console.warn(`Failed to retrieve data for ${city.name}.`, error);
      return { id: city.id, value: { error: error?.message || "Network error" } };
    }
  }));
  // Ignore an older batch if a newer refresh began after the city list changed.
  if (generation !== state.refreshGeneration) return;
  const currentIds = new Set(state.cities.map(city => city.id));
  state.cityData = new Map(results.filter(result => currentIds.has(result.id)).map(result => [result.id, result.value]));
  renderCityCards();
  updateCharts();
  el.refreshButton.disabled = false;
  el.refreshButton.innerHTML = '<span aria-hidden="true">↻</span> Refresh data';
  const failed = results.filter(result => result.value.error).length;
  if (failed) showStatus(`${failed} city/cities could not load. Check your connection and refresh.`, "error");
  else if (typeof Chart === "undefined") { /* preserve the chart-library warning */ }
  else if (el.status.classList.contains("info") && !el.searchResults.hidden) { /* preserve city-choice guidance */ }
  else if (el.status.classList.contains("error") && !el.searchResults.hidden) { /* preserve search feedback */ }
  else clearStatus();
}

function addCityToComparison(input) {
  const city = normalizeCity(input);
  if (!city) {
    showStatus("That location could not be identified. Try a city name with its country.", "error");
    return false;
  }
  if (state.cities.some(item => item.id === city.id)) {
    showStatus(`${city.name} is already in your comparison.`, "info");
    return false;
  }
  if (state.cities.length >= MAX_CITIES) {
    showStatus(`You can compare up to ${MAX_CITIES} cities at once. Remove a city before adding another.`, "error");
    return false;
  }
  state.cities.push(city);
  saveCities();
  hideSearchResults();
  renderCityCards();
  renderFavouriteCities();
  void refreshDashboard();
  showStatus(`${city.name}${city.country ? `, ${city.country}` : ""} added to your comparison.`, "success");
  return true;
}

el.cityForm.addEventListener("submit", async event => {
  event.preventDefault();
  const query = el.cityInput.value.trim();
  if (query.length < 2) {
    showStatus("Enter at least two characters to search for a city.", "error");
    return;
  }
  hideSearchResults();
  el.addCityButton.disabled = true;
  el.addCityButton.innerHTML = "<span>…</span> Searching";
  showStatus(`Searching for “${query}”…`, "info");
  try {
    const params = new URLSearchParams({ name: query, count: "5", language: "en", format: "json" });
    const payload = await fetchJSON(`${API.geocoding}?${params}`);
    const matches = Array.isArray(payload.results) ? payload.results : [];
    if (!matches.length) {
      showStatus("No matching city found. Try another spelling or include the country name.", "error");
    } else {
      renderSearchResults(matches);
      if (state.searchMatches.length === 1) {
        const onlyMatch = state.searchMatches[0];
        hideSearchResults();
        addCityToComparison(onlyMatch);
        el.cityInput.value = "";
      }
    }
  } catch (error) {
    console.warn("City search failed.", error);
    showStatus(error?.message || "City search failed. Check your internet connection and try again.", "error");
  } finally {
    el.addCityButton.disabled = false;
    el.addCityButton.innerHTML = "<span>＋</span> Add city";
  }
});

el.searchResults.addEventListener("click", event => {
  const button = event.target.closest("[data-search-result]");
  if (!button) return;
  const city = state.searchMatches[Number(button.dataset.searchResult)];
  if (city && addCityToComparison(city)) el.cityInput.value = "";
});

el.cityGrid.addEventListener("click", event => {
  const favouriteButton = event.target.closest("[data-favourite]");
  const removeButton = event.target.closest("[data-remove-city]");
  if (favouriteButton) {
    const city = state.cities.find(item => item.id === favouriteButton.dataset.favourite);
    if (!city) return;
    state.favourites = state.favourites.some(item => item.id === city.id)
      ? state.favourites.filter(item => item.id !== city.id)
      : [...state.favourites, city];
    saveFavourites();
    renderCityCards();
    renderFavouriteCities();
  }
  if (removeButton) {
    state.cities = state.cities.filter(item => item.id !== removeButton.dataset.removeCity);
    saveCities();
    state.cityData.delete(removeButton.dataset.removeCity);
    clearStatus();
    renderCityCards();
    renderFavouriteCities();
    void refreshDashboard();
  }
});

el.favoritesList.addEventListener("click", event => {
  const compareButton = event.target.closest("[data-recompare]");
  const removeButton = event.target.closest("[data-unfavorite]");
  if (compareButton && !compareButton.disabled) {
    const city = state.favourites.find(item => item.id === compareButton.dataset.recompare);
    if (city) addCityToComparison(city);
  }
  if (removeButton) {
    state.favourites = state.favourites.filter(item => item.id !== removeButton.dataset.unfavorite);
    saveFavourites();
    renderFavouriteCities();
    renderCityCards();
  }
});

el.refreshButton.addEventListener("click", () => {
  clearStatus();
  void refreshDashboard();
});

// Initial render uses three sample locations, then fetches current API responses.
renderCityCards();
renderFavouriteCities();
void refreshDashboard();
