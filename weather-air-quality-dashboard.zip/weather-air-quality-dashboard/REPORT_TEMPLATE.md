# Weather & Air Quality Dashboard
## University Project Report — Editable Draft

> **Before submission:** replace every bracketed placeholder with your actual information, add genuine screenshots from your running application, update the testing table with results you observed, and follow your instructor's required report format. Do not submit tests as passed unless you performed them.

### Title page

**Project title:** Weather & Air Quality Dashboard  
**Student name:** [Enter name]  
**Roll number:** [Enter roll number]  
**Programme / class:** [Enter programme]  
**Subject / module:** [Enter subject]  
**Instructor:** [Enter instructor]  
**Institution:** [Enter institution]  
**Submission date:** [Enter date]

## 1. Abstract

The Weather & Air Quality Dashboard is a responsive web application designed to compare weather conditions and model-based air-quality information across multiple cities. It retrieves location coordinates using a geocoding service, requests weather and air-quality data from public APIs, and visualises hourly forecasts with interactive line charts. Users can maintain a comparison list and save favourite cities in browser storage. The project demonstrates API integration, asynchronous JavaScript, JSON processing, data visualisation, client-side state management, and responsive interface design.

## 2. Introduction and problem statement

Weather information and air-quality indicators can be difficult to compare when they are presented on separate pages. This project brings selected weather and air-quality indicators together in one dashboard so that users can view multiple locations in a consistent layout and inspect forecast changes over the next 24 hours.

The project is an educational demonstration. The displayed model-based values are not guaranteed readings from nearby government monitoring stations, and the selected European AQI is not India's CPCB National AQI.

## 3. Objectives

1. Retrieve weather information through a public API.
2. Retrieve air-quality indicators through a public API.
3. Search for and compare multiple cities.
4. Use interactive charts to compare hourly temperature and AQI forecasts.
5. Save and restore favourite cities using browser storage.
6. practise separating application structure, styling, logic, documentation and testing.

## 4. Requirements

| Requirement | Implementation | Evidence to capture |
| --- | --- | --- |
| Weather API | Open-Meteo Weather Forecast API | [Add screenshot of weather cards and Network response] |
| Air-quality API | Open-Meteo Air Quality API | [Add screenshot showing European AQI, PM2.5 and PM10] |
| Multiple-city comparison | Up to six city cards | [Add screenshot with at least three cities] |
| Trend charts | Chart.js hourly temperature and AQI charts | [Add screenshot of both charts] |
| Saved cities | `localStorage` favourites | [Add screenshots before/after saving and after refresh] |

## 5. Technologies used

- **HTML5:** defines the page structure and semantic sections.
- **CSS3:** provides visual styling and responsive layouts.
- **Vanilla JavaScript:** handles events, API requests, data processing, local storage, and rendering.
- **Open-Meteo Weather Forecast API:** supplies model-based current conditions and hourly weather forecasts.
- **Open-Meteo Air Quality API:** supplies supported air-quality variables and hourly estimates/forecasts.
- **Open-Meteo Geocoding API:** converts city searches into location candidates and coordinates.
- **Chart.js:** renders interactive comparison charts.
- **Browser `localStorage`:** persists selected cities and favourites within the browser profile and origin.

## 6. System design and data flow

The user enters a city name. The geocoding API returns matching locations; when more than one result is available, the user can select the intended result. The chosen location's latitude and longitude are used for separate weather and air-quality requests. The JavaScript code checks response status, handles unavailable services, stores the result in application state, and updates the city cards and charts. The favourite feature serialises city identity and coordinates to browser local storage.

**Data flow:** City search → geocoding → city selection → weather/AQ API requests → response validation → state update → card and chart rendering → optional favourite persistence.

## 7. Main features

### 7.1 Weather information

Each city card displays temperature, apparent temperature, humidity, wind speed and a human-readable weather condition. Weather conditions are derived from the returned weather code.

### 7.2 Air-quality information

The dashboard displays European AQI, PM2.5 and PM10 where provided. It explicitly labels the index standard to reduce the risk of interpreting European AQI as the Indian CPCB standard. Missing values are displayed as unavailable rather than zero.

### 7.3 City comparison

Users can search for a city and select a result. The dashboard prevents duplicate coordinates and limits the comparison to six locations to keep cards and charts readable.

### 7.4 Forecast charts

Two Chart.js line charts compare hourly temperature and European AQI. The time labels use UTC, and values are aligned by timestamp so that the comparison is not based solely on array position. These are forecast charts, not historical trend charts.

### 7.5 Saved favourites

Users can save or remove a city with a star control. Saved cities appear in a separate list and can be added back into the comparison. The lists persist with browser `localStorage`.

## 8. Error handling and limitations

The application handles failed requests, loading states, invalid searches, unavailable fields and browser storage errors. It uses external API and CDN services, so internet access is required. Service availability and forecast accuracy are not guaranteed. Free API use has conditions and rate limits. The application is frontend-only and does not synchronise favourites across devices. It does not use a historical weather data endpoint, and it does not calculate Indian CPCB AQI.

## 9. Testing methodology and results

Perform the checks in `TESTING_CHECKLIST.md` using the browser. Replace this table with the actual observed results.

| Test | Expected result | Actual result | Status |
| --- | --- | --- | --- |
| Load dashboard | Default locations render; charts appear if services load | [Record result] | [Pass/Fail/Not run] |
| Search a valid city | Correct candidate(s) appear and can be added | [Record result] | [Pass/Fail/Not run] |
| Search invalid text | Helpful no-results message appears | [Record result] | [Pass/Fail/Not run] |
| Compare three cities | Three cards and corresponding chart series appear | [Record result] | [Pass/Fail/Not run] |
| Save favourite | City appears in saved section | [Record result] | [Pass/Fail/Not run] |
| Refresh after saving | Favourite remains saved | [Record result] | [Pass/Fail/Not run] |
| Remove city | City and its chart dataset are removed | [Record result] | [Pass/Fail/Not run] |
| API failure | Clear error or partial-data message appears | [Record result] | [Pass/Fail/Not run] |

## 10. Conclusion

The project brings public weather and air-quality API data into a single interface and demonstrates essential frontend programming practices. It gives users a way to compare cities, inspect hourly forecast charts and retain favourites between sessions. The application can be extended with more pollutants, selectable AQI standards, CSV export or a different data source if a future requirement calls for it.

## 11. References

1. Open-Meteo, Weather Forecast API documentation: <https://open-meteo.com/en/docs>
2. Open-Meteo, Air Quality API documentation: <https://open-meteo.com/en/docs/air-quality-api>
3. Open-Meteo, Geocoding API documentation: <https://open-meteo.com/en/docs/geocoding-api>
4. Open-Meteo, terms of use: <https://open-meteo.com/en/terms>
5. Chart.js documentation: <https://www.chartjs.org/docs/latest/>
6. GeoNames: <https://www.geonames.org/>
