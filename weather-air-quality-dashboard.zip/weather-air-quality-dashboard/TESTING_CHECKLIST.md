# Testing Checklist

Run these checks in the browser with an active internet connection and the project served from VS Code Live Server. Record the date, browser, observed behaviour and any defect. Do not mark tests passed without performing them.

## A. Basic startup

- [ ] Open `index.html` using Live Server.
- [ ] Confirm the page layout appears without broken styles.
- [ ] Confirm three initial locations are listed (unless the browser has previously saved a different comparison list).
- [ ] Confirm weather cards populate when the API is reachable.
- [ ] Confirm both charts appear when the chart library and API data load.
- [ ] Open DevTools → Console and record any errors.

## B. Search and comparison

- [ ] Search a valid city with one clear match.
- [ ] Search a name that has multiple matching places; select the correct country/region.
- [ ] Search an unknown city and confirm a no-results message.
- [ ] Try an empty/one-character search and confirm validation.
- [ ] Add at least three cities and confirm the correct number of cards and chart series.
- [ ] Try adding a duplicate city and confirm it is prevented.
- [ ] Add a seventh city and confirm the maximum-six message appears.
- [ ] Remove a city and confirm its card and chart series disappear.

## C. Weather and air quality

- [ ] Confirm temperature, apparent temperature, humidity and wind speed display when returned by the API.
- [ ] Confirm weather codes have readable descriptions.
- [ ] Confirm European AQI, PM2.5 and PM10 display when provided.
- [ ] Confirm unavailable values appear as a dash, not as zero.
- [ ] Confirm the interface identifies the air-quality index as European AQI.
- [ ] Confirm the dashboard's note does not describe model-based estimates as guaranteed monitoring-station measurements.

## D. Charts

- [ ] Confirm the temperature chart contains a series for each successfully loaded city.
- [ ] Confirm the AQI chart contains a series when hourly AQI data are available.
- [ ] Confirm axis titles, legends and tooltips are readable.
- [ ] Confirm forecast times use the shared UTC timeline.
- [ ] Refresh data and confirm chart updates without duplicate chart canvases or console errors.
- [ ] Check chart readability in a narrow/mobile viewport.

## E. Favourite persistence

- [ ] Save a city as a favourite.
- [ ] Confirm it appears in the saved cities section and the star indicates saved state.
- [ ] Remove it from favourites and confirm it disappears from that section.
- [ ] Save it again, reload the page and confirm the favourite remains.
- [ ] Use the saved city to add it to comparison.
- [ ] Confirm already-compared favourites cannot be added twice.

## F. Failure cases

- [ ] Temporarily disable the network and use Refresh data; confirm an understandable error appears.
- [ ] If possible, use DevTools Network request blocking to test one endpoint failing while the other succeeds.
- [ ] Confirm a failed air-quality request does not erase weather information.
- [ ] Confirm local-storage data survives a normal refresh.
- [ ] Optional developer test: use DevTools Application → Local Storage to replace a saved list with invalid JSON, reload, and confirm the page does not crash.

## Results record

- Test date/time: [Fill in]
- Browser/version: [Fill in]
- Device/viewport: [Fill in]
- Tests passed: [Count]
- Tests failed: [Count]
- Tests not run: [Count]
- Defects and corrective action: [Fill in]

## Automated checks already run in the package-building environment

See `VALIDATION_RESULTS.md` for the exact checks, outcomes and testing limitations. The passing static checks do not replace live API or browser testing.
