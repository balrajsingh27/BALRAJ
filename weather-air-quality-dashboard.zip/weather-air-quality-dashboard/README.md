# Atmos — Weather & Air Quality Dashboard

A responsive, beginner-friendly university project that compares model-based weather and air-quality information for multiple cities. It uses public Open-Meteo endpoints, Chart.js for interactive hourly charts, and browser `localStorage` for city favourites.

## Features

- Current weather fields: temperature, feels-like temperature, relative humidity, wind speed and a readable weather-code description.
- Air-quality fields: European Air Quality Index (AQI), PM2.5 and PM10.
- Geocoding search with a choice of matching locations when names are ambiguous.
- Comparison of up to six cities; three sample Indian locations are loaded on first use.
- Hourly temperature and European AQI comparison charts.
- Save/remove favourite cities and re-add favourites to the comparison.
- Persist comparison selections and favourites in browser `localStorage`.
- Loading, network error, empty-state and partial-air-data feedback.
- UTC-aligned forecast timestamps, responsive styling and basic accessible labels.

## Project structure

```text
weather-air-quality-dashboard/
├── index.html             # Semantic page structure and chart canvases
├── styles.css             # Responsive visual design
├── app.js                 # API calls, city management, storage and charts
├── README.md              # Setup and project documentation
├── REPORT_TEMPLATE.md     # Assignment report draft with fields to personalise
├── TESTING_CHECKLIST.md   # Manual verification checklist
└── VIVA_PREPARATION.md    # Demonstration outline and practice questions
```

## Run the project

1. Download and extract the ZIP folder.
2. Open the extracted folder in Visual Studio Code.
3. Recommended: install the **Live Server** extension in VS Code, then right-click `index.html` and select **Open with Live Server**. A local server makes the browser workflow more predictable than opening a file directly.
4. Keep an internet connection enabled. Open-Meteo data and the Chart.js library are loaded online.
5. The initial comparison includes Panipat, New Delhi and Mumbai. Search for another city, choose the right match if multiple results appear, and add it.
6. Select the star icon on a city card to save or remove a favourite. Use the saved-city section to restore a city to the comparison.

No API key, Node.js installation or build step is required for the intended non-commercial student demo.

## APIs and dependencies

- Weather Forecast API: <https://open-meteo.com/en/docs>
- Air Quality API: <https://open-meteo.com/en/docs/air-quality-api>
- Geocoding API: <https://open-meteo.com/en/docs/geocoding-api>
- Chart.js documentation: <https://www.chartjs.org/docs/latest/>
- Open-Meteo usage terms: <https://open-meteo.com/en/terms>

The app sends coordinates from the geocoding service to the weather and air-quality endpoints. Independent weather and air-quality requests are handled separately so that an air-quality failure can be shown without discarding successfully retrieved weather data.

## Understanding the data

- The charts show **hourly forecast data**, not historical trends.
- The chart time labels use UTC so that city timelines can be aligned consistently.
- This project displays **European AQI**. It is not the Indian CPCB National AQI or the US AQI scale. Index values and category labels should not be compared across different standards as if they were identical.
- Weather and air-quality values are model-based estimates/forecasts. They are not guaranteed to be direct readings from a nearby government monitoring station. The location returned by an API may also correspond to a model grid cell several kilometres from the search coordinate.
- A value displayed as `—` means the API did not provide a usable value; it is not zero.

## Browser storage

The browser stores selected comparison cities and favourite city coordinates under two keys:

- `atmos-dashboard-cities-v1`
- `atmos-dashboard-favourites-v1`

These values are local to the browser profile and origin. Clearing browser storage removes them. The app validates stored city coordinates and handles invalid stored JSON by falling back to safe defaults.

## Attribution and usage

The dashboard credits **Open-Meteo** for the weather and air-quality services and **GeoNames** for location data; **Chart.js** supplies the charts. Open-Meteo states that its data is licensed under CC BY 4.0 and that its free API is for non-commercial use, subject to rate limits and other current terms. Review the provider's current terms before public or commercial deployment and retain appropriate attribution.

## Troubleshooting

- **Cards stay in a loading state:** confirm that Live Server is running and the browser has internet access; open DevTools → Console and Network to see request errors.
- **Chart area is empty:** confirm that the Chart.js CDN script loaded and that the API returned hourly data.
- **Air-quality fields show `—`:** the service may not have a usable value for that variable or location at that time. Check again later; do not interpret missing as zero.
- **Wrong city appears:** include the country or region in the search term, then select the intended item from the location results.
- **Favourites disappear:** use the same browser profile and local origin. Clearing site data or switching browsers changes browser storage.
- **Too many cities:** the UI allows up to six simultaneous comparison locations; remove one first.

## Suggested improvements

Possible extensions after the mandatory features work include CSV export, a user-selectable AQI standard, chart selection for additional pollutants, optional units, a proper CPCB AQI source for India, or server-side caching for larger deployments.
