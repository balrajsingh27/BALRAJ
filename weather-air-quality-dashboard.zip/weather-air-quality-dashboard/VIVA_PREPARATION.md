# Demonstration Outline and Viva Preparation

## Suggested 2–3 minute demonstration

1. **Introduce the project:** “This is a Weather & Air Quality Dashboard. It uses public APIs to compare weather and model-based air-quality estimates across cities.”
2. **Show the default comparison:** Explain temperature, humidity, wind speed, European AQI, PM2.5 and PM10.
3. **Search for a city:** Enter a city name and show how multiple geocoding matches can be selected.
4. **Compare locations:** Add a city and show that its card and line appear in the charts.
5. **Explain the charts:** Temperature and European AQI charts show hourly forecast values with a common UTC timeline.
6. **Demonstrate favourites:** Select the star, show the saved list, refresh the browser and show the favourite remains.
7. **Close with limitations:** Explain that model-based forecasts are not the same as government monitoring-station readings and that European AQI differs from Indian CPCB AQI.

## Viva questions and sample answers

### 1. What is the purpose of this project?
It brings weather and air-quality information for several cities into one interface and uses charts to make hourly forecast comparisons easier.

### 2. What is an API?
An API is an interface that allows one software system to request data or services from another. This application requests data from public Open-Meteo endpoints.

### 3. What does `fetch()` do?
`fetch()` makes a network request and returns a Promise representing the response. The code checks the response status and then reads the JSON data.

### 4. Why are `async` and `await` used?
They make asynchronous code easier to read. `await` pauses the current async function until a Promise settles without blocking the browser's main thread in the same way as a synchronous request.

### 5. What is JSON?
JSON is a text format for structured data. The API responses are parsed into JavaScript objects so the dashboard can read fields such as temperature and hourly time arrays.

### 6. Why does the project need geocoding?
Weather endpoints need coordinates. Geocoding turns a city search into matching locations with latitude and longitude.

### 7. Why use latitude and longitude instead of only a city name?
Coordinates make the weather and air-quality requests unambiguous after the user chooses the intended location.

### 8. What is `localStorage`?
It is browser storage that keeps string key-value pairs for an origin across normal page reloads. The project uses JSON serialization to save and restore city lists.

### 9. What is Chart.js used for?
Chart.js creates the line charts from API data arrays. The application updates or destroys existing chart instances when the selected city data changes.

### 10. What is the difference between a forecast and a historical trend?
A forecast estimates future conditions. Historical data represents past observations or archived model values. This starter primarily visualises the next 24 hours of forecast data, so its charts should be called forecasts rather than historical trends.

### 11. Does European AQI mean the Indian CPCB AQI?
No. They use different standards and scales. The dashboard labels European AQI clearly and should not present it as the CPCB National AQI.

### 12. Are the values measurements from a nearby government station?
Not necessarily. These services provide model-based estimates and forecasts. They should not be described as guaranteed observations from a monitoring station.

### 13. How does the dashboard handle an API failure?
The requests use error handling and response checks. Weather and air-quality calls are handled independently; if air quality fails but weather succeeds, the app can still show weather and explain that air-quality data are unavailable.

### 14. Why limit comparison to six cities?
It provides a practical limit that helps keep the cards and chart legends usable. It also helps control the number of requests the frontend makes.

### 15. What happens if the user reloads the page?
The browser reloads the saved city lists from localStorage, renders the interface, and requests fresh API data. It does not store a permanent snapshot of the weather readings.

### 16. What are the main limitations?
The app depends on internet connectivity and external services, does not guarantee forecast accuracy, stores favourites only in the current browser profile, and uses European AQI rather than India's CPCB scale.

### 17. What does `Promise.allSettled()` do here?
It waits for several Promises to settle and gives each one's success or failure result. It is useful when weather and air-quality requests should be evaluated separately rather than failing as a single combined operation.

### 18. What would you improve next?
Possible enhancements include adding a data-source selector, CSV export, additional pollutant charts, optional temperature units, automated end-to-end tests, and an Indian CPCB AQI data source if that requirement is added.

> Use these answers as study notes. Be prepared to describe the actual code and the tests you personally performed rather than memorising responses word for word.
