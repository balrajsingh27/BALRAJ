# Validation Results

**Validation date:** 12 October 2026

## Checks completed

| Check | Result | Notes |
| --- | --- | --- |
| JavaScript syntax (`node --check app.js`) | PASS | Node.js syntax checker reported no syntax errors. |
| Required project files exist and are non-empty | PASS | HTML, CSS, JS, README, report template, testing checklist and viva guide are present. |
| HTML IDs referenced by JavaScript selectors | PASS | All 12 selector IDs checked by the validation script were found in the HTML. |
| Weather API endpoint present | PASS | Uses the Open-Meteo Forecast endpoint. |
| Air-quality API endpoint present | PASS | Uses the Open-Meteo Air Quality endpoint. |
| Geocoding API endpoint present | PASS | Uses the Open-Meteo Geocoding endpoint. |
| Chart integration present | PASS | Both line charts are constructed through Chart.js. |
| Favourite persistence present | PASS | Uses browser `localStorage`. |
| PM10 visual metric present | PASS | City cards include PM10 as a separate metric. |
| Ambiguous search selection present | PASS | Search results can be selected from a list. |
| Six-city cap present | PASS | Application-level limit set to six comparison cities. |
| Invalid `past_hours=0` parameter absent | PASS | The unnecessary parameter has been removed from the air-quality request. |
| Supporting documentation present | PASS | Report, testing and viva documents are included. |

## Checks not completed in this environment

- **Live API response test:** A direct network attempt failed because outbound DNS resolution was unavailable. The API request syntax was checked against official documentation, but live response contents were not verified here.
- **Browser-driven end-to-end test:** Playwright is installed as a Python package, but a compatible Chromium executable is not installed in this environment. Interactive layout, browser-console behaviour, charts and persistence must therefore be checked manually by opening the application in a browser.
- **Responsive visual inspection:** Not performed in a live browser here; follow the viewport tests in `TESTING_CHECKLIST.md`.

## Interpretation

The PASS results above refer only to the checks actually executed. They do not prove that every feature works against live services in every browser. Complete the manual checklist, record real outcomes and fix any issues observed before final submission.
